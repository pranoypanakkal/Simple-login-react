import httpClient from "../core/httpClient/httpClient";

export function setUserDetails(email, password) {
  return function (dispatch, getState) {
    console.log("Called actions");
    //Http calls here

    // httpClient
    //   .post({
    //     path: url,
    //     data: {},
    //   })
    //   .then(
    //     (res) => {
    //       return res;
    //     },
    //     (err) => {
    //       return err;
    //     }
    //   );

    //Dispatching values to reducer
    return dispatch({
      type: "SET_USER_DETAILS",
      payload: {
        email: email,
        password: password,
      },
    });
  };
}
