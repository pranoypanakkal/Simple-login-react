import logo from "../../logo.svg";
import "./App.css";
import {
  Row,
  Col,
  Container,
  Card,
  Accordion,
  Button,
  Modal,
  Form,
} from "react-bootstrap";
import { Login } from "../Login";
import { BasicInformation } from "../BasicInformation";
import {
  HashRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <Login />
        </Route>
        <Route exact path="/homepage">
          <BasicInformation />
        </Route>
        <Route render={() => <Redirect to={{ pathname: "/" }} />} />
      </Switch>
    </Router>
  );
}

export default App;
