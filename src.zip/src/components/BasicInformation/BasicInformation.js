import React, { useEffect } from "react";
import "./BasicInformation.css";
import { Container } from "react-bootstrap";
import { useSelector } from "react-redux";

function BasicInformation() {
  const userDetails = useSelector((state) => state.LoginReducer); // Hooks for mapStateToProps

  useEffect(() => {}, [userDetails]); // Hooks for componentDidMount and componentDidUpdate

  console.log(userDetails);

  return (
    <Container fluid className="d-flex justify-content-center">
      <div className="resume-form">
        <div className="form-header">
          <h2 className="form-title">Personal details</h2>
          <div>Name :- {userDetails.userName}</div>
          <div>Email :- {userDetails.email}</div>
          <div>Number :- {userDetails.phoneNumber}</div>
        </div>
      </div>
    </Container>
  );
}

export default BasicInformation;
