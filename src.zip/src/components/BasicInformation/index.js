import BasicInformation from "./BasicInformation";

export { BasicInformation };
