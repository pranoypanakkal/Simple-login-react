import axios from "axios";

function resolveUrl(path) {
  return path;
}

const httpClient = {
  get: ({ path }) => axios.get(resolveUrl(path)),
  post: ({ path, data }) => axios.post(resolveUrl(path), data),
  put: ({ path, data }) => axios.put(resolveUrl(path), data),
  delete: ({ path, data }) => axios.delete(resolveUrl(path), { data: data }),
  postWithCancelToken: ({ path, data, cancel_Token }) =>
    axios.post(resolveUrl(path), data, cancel_Token),
};

export default httpClient;
