import httpClient from "./httpClient";

export { httpClient };
