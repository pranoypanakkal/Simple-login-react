const initialState = {
  userName: "pranoy",
  password: "",
  email: "",
  phoneNumber: "8972542652",
};

const LoginReducer = (state = initialState, action) => {
  switch (action.type) {
    case "SET_USER_DETAILS": {
      console.log("reducer");
      console.log(action.payload);
      let newState = JSON.parse(JSON.stringify(state));
      newState.email = action.payload.email;
      newState.password = action.payload.password;
      return newState;
    }
    default:
      return state;
  }
};

export default LoginReducer;
