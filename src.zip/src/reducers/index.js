import { combineReducers } from "redux";
import LoginReducer from "./LoginReducer";

const combinedReducers = combineReducers({
  LoginReducer,
});

export default combinedReducers;
